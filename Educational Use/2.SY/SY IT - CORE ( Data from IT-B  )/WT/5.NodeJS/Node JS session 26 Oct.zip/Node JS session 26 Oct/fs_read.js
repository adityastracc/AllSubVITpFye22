// const fs = require('fs');

// // Synchronous file read
// try {
//   const data = fs.readFileSync('example.txt', 'utf8');
//   console.log(data);
// } catch (err) {
//   console.error('Error reading file:', err);
// }


const fs = require('fs');

// Asynchronous file read
fs.readFile('example.txt', 'utf8', (err, data) => {
  if (err) {
    console.error('Error reading file:', err);
    return;
  }
  console.log(data);
});

