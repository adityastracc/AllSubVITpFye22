// const fs = require('fs');

// try {
//   fs.writeFileSync('output.txt', 'This is some content.', 'utf8');
//   console.log('File written successfully.');
// } catch (err) {
//   console.error('Error writing file:', err);
// }

const fs = require('fs');

// Asynchronous file write
fs.writeFile('output.txt', 'This is some content in Asynchronous file write.', 'utf8', (err) => {
  if (err) {
    console.error('Error writing file:', err);
    return;
  }
  console.log('File written successfully.');
});
