const express = require('express');
const mongoose = require('mongoose');

const app = express();
const PORT = process.env.PORT || 3000; // Define your preferred port

// MongoDB connection URL and options
const MONGODB_URI = 'mongodb://localhost:27017/your-database-name';
const mongooseOptions = {
  useNewUrlParser: true,
  useUnifiedTopology: true,
};

// Connect to MongoDB
mongoose
  .connect(MONGODB_URI, mongooseOptions)
  .then(() => {
    console.log('Connected to MongoDB');
  })
  .catch((error) => {
    console.error('Error connecting to MongoDB:', error);
  });

// Define a simple test route
app.get('/', (req, res) => {
  res.send('Server is running, and MongoDB is connected.');
});

app.post('/', (req, res) => {

});


// Start the Express server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
