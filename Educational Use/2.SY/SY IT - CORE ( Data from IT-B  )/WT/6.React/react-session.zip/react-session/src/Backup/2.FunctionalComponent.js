//! demo of functional components with function keyword

// function FunctionalComponent() {
//   return (
//     <div>
//       <h1>Functional Component</h1>
//     </div>
//   );
// }

// export default FunctionalComponent;

//! demo of functional components with arrow function

// const FunctionalComponent = () => {
//   return (
//     <div>
//       <h1>Functional Component</h1>
//     </div>
//   );
// };

// export default FunctionalComponent;

//! demo of states in functional component

// import { useState } from "react";

// const FunctionalComponent = () => {
//   const [message, setMessage] = useState("Welcome Visitor");
//   const changeMessage = () => {
//     setMessage("Thank you for subscribing");
//   };
//   return (
//     <div>
//       <h1>{message}</h1>
//       <button onClick={() => changeMessage()}>Subscribe</button>
//     </div>
//   );
// };

// export default FunctionalComponent;

//! demo of props in functional component

// const FunctionalComponent = (props) => {
//   return (
//     <div>
//       <h1>Welcome {props.name}</h1>
//     </div>
//   );
// };

// export default FunctionalComponent;

// ! demo of useEffect hook and fetch frunction

// import { useState, useEffect } from "react";

// const FunctionalComponent = () => {
//   const [name, setName] = useState("Bruce");
//   useEffect(() => {
//     console.log("You are typing " + name);
//   }, [name]);

//   return (
//     <div>
//       <input
//         type="text"
//         value={name}
//         onChange={(e)=>setName(e.target.value)}
//       ></input>
//       <br />
//     </div>
//   );
// };

// export default FunctionalComponent;
