import React from "react";
import { useNavigate, useLocation } from "react-router-dom";

const About = () => {
  let navigate = useNavigate();
  let location = useLocation();
  console.log(location.pathname);
  return (
    <div>
      About
      <button onClick={() => navigate("/testing")}>redirect</button>
    </div>
  );
};

export default About;
