// ! demo of forms

import { useState } from "react";

const Forms = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(name, email);
    alert(`Name: ${name} Email: ${email}`);
  };

  return (
    <div>
      <h1>Forms</h1>
      <form onSubmit={handleSubmit}>
        <label>Name</label>
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <br></br>
        <label>Email</label>
        <input
          type="text"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <br></br>
        <button type="submit">Submit</button>
      </form>
      <h2>Name: {name}</h2>
      <h2>Email: {email}</h2>
    </div>
  );
};

export default Forms;

// ! demo of forms with useRef without using state

// import { useRef } from "react";

// const Forms = () => {
//   const formRef = useRef(null);
//   const handleSubmit = (e) => {
//     e.preventDefault();
//     const formData = new FormData(formRef.current); // gets form data
//     const data = Object.fromEntries(formData); // converts form data to object
//     console.log(data);
//     alert(`Name: ${data.name} Email: ${data.email}`);
//   };

//   return (
//     <div>
//       <h1>Forms</h1>
//       <form ref={formRef} onSubmit={handleSubmit}>
//         <label>Name</label>
//         <input type="text" name="name" />
//         <br></br>
//         <label>Email</label>
//         <input type="text" name="email" />
//         <br></br>
//         <button type="submit">Submit</button>
//       </form>
//     </div>
//   );
// };

// export default Forms;
