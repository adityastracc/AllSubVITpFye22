// ! demo of various event handlers

import { useState } from "react";

const EventHandling = () => {
  const [name, setName] = useState("");
  const [message, setMessage] = useState("");
  const [names, setNames] = useState([]);
  const [isError, setIsError] = useState(false);
  const [isButtonClicked, setIsButtonClicked] = useState(false);
  const [isMouseOver, setIsMouseOver] = useState(false);

  const changeName = (e) => {
    setName(e.target.value);
  };

  const changeMessage = (e) => {
    setMessage(e.target.value);
  };

  const submitForm = (e) => {
    e.preventDefault();
    if (name && message) {
      setIsError(false);
      setIsButtonClicked(true);
      setNames([...names, { name: name, message: message }]);
      setName("");
      setMessage("");
    } else {
      setIsError(true);
    }
  };

  const mouseOver = () => {
    setIsMouseOver(true);
  };

  const mouseOut = () => {
    setIsMouseOver(false);
  };

  return (
    <div>
      <form onSubmit={submitForm}>
        <input
          type="text"
          placeholder="Enter your name"
          value={name}
          onChange={changeName}
        />
        <input
          type="text"
          placeholder="Enter your message"
          value={message}
          onChange={changeMessage}
        />
        <button type="submit" onMouseOver={mouseOver} onMouseOut={mouseOut}>
          Submit
        </button>
      </form>
      {isError && <h1>Please enter name and message</h1>}
      {isButtonClicked &&
        names.map((name) => (
          <h2>
            {name.name} {name.message}
          </h2>
        ))}
      {isMouseOver && <h1>Mouse is over</h1>}
    </div>
  );
};

export default EventHandling;
