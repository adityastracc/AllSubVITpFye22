

// //! demo of react router dom

// import React from "react";
// import { BrowserRouter as Router, Route, Routes, Link } from "react-router-dom";
// import ConditionalRendering from "./3.ConditionalRendering";
// import EventHandling from "./6.EventHandling";

// const ReactRouterDom = () => {
//     return (
//         <Router>
//         <div>
//             <ul>
//             <li>
//                 <Link to="/home">Home</Link>
//             </li>
//             <li>
//                 <Link to="/about">About</Link>
//             </li>
//             </ul>
//             <Routes>
//             <Route path="/home" exact component={<ConditionalRendering/>} />
//             <Route path="/about" component={<EventHandling/>} />
//             </Routes>
//         </div>
//         </Router>
//     );
// }
    
// export default ReactRouterDom;