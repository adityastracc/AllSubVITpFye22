import logo from "./logo.svg";
import "./App.css";
import ClassComponent from "./Components/ClassComponent";
import FuncComp from "./Components/FunctionalComponent";
import Forms from "./Components/Forms";
import Homepage from "./pages/Homepage";
import About from "./pages/About";
import Navbar from "./pages/Navbar";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Router>
          <div>
            <Navbar />
            <Routes>
              <Route path="/" exact element={<Homepage />} />
              <Route path="/about" element={<About />} />
              <Route path="/testing" element={<h1>This is testing...</h1>} />
            </Routes>
          </div>
        </Router>
      </header>
    </div>
  );
}

export default App;
