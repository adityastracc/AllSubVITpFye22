//! demo of class component

import React, { Component } from "react";

class ClassComponent extends Component {
  render() {
    return (
      <div>
        <h1>Class Component</h1>
      </div>
    );
  }
}

export default ClassComponent;

//! demo of states in class component

// import React, { Component } from "react";

// class ClassComponent extends Component {
//   constructor() {
//     super();
//     this.state = {
//       message: "Welcome Visitor",
//     };
//   }
//   changeMessage() {
//     this.setState({
//       message: "Thank you for subscribing",
//     });
//   }
//   render() {
//     return (
//       <div>
//         <h1>{this.state.message}</h1>
//         <button onClick={() => this.changeMessage()}>Subscribe</button>
//       </div>
//     );
//   }
// }

// export default ClassComponent;

//! demo of props in class component

// import React, { Component } from "react";

// class ClassComponent extends Component {
//   render() {
//     return (
//       <div>
//         <h1>
//           Welcome {this.props.name} 
//         </h1>
//       </div>
//     );
//   }
// }

// export default ClassComponent;