import { useRef } from "react";

const Forms = () => {
  const formRef = useRef(null);

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(formRef.current); // gets form data
    const data = Object.fromEntries(formData); // converts form data to object
    console.log(data);
    alert(`Name: ${data.name} Email: ${data.email}`);
  };

  return (
    <div>
      <h1>Forms</h1>
      <form ref={formRef} onSubmit={handleSubmit}>
        <label>Name</label>
        <input type="text" name="name" />
        <br></br>
        <label>Email</label>
        <input type="text" name="email" />
        <br></br>
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default Forms;
