// ! demo of map function

import { useState } from "react";

const MapFunction = () => {
    let names = [
        { id: 1, name: "Bruce", age: 30 },
        { id: 2, name: "Clark", age: 25 },
        { id: 3, name: "Diana", age: 28 },
      ]
  return (
    <div>
      {names.map((name) => (
        <h2>
          {name.id} {name.name} {name.age}
        </h2>
      ))}
    </div>
  );
};

export default MapFunction;
