// ! demo of conditional rendering using functional component

import { useState } from "react";

const ConditionalRendering = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(true);
  return (
    <div>{isLoggedIn ? <h1>Welcome User</h1> : <h1>Welcome Guest</h1>}</div>
  );
};

export default ConditionalRendering;
