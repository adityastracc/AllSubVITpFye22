
// ! demo of filter function

import { useState } from "react";

const FilterFunction = () => {
    let names = [
        { id: 1, name: "Bruce", age: 30 },
        { id: 2, name: "Clark", age: 25 },
        { id: 3, name: "Diana", age: 28 },
      ]
  return (
    <div>
      {names.filter((name) => name.age > 25).map((name) => (
        <h2>
          {name.id} {name.name} {name.age}
        </h2>
      ))}
    </div>
  );
}

export default FilterFunction;