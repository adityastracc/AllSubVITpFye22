import { useState } from "react";

function FuncComp() {
  const arr = ["Tanmay", "Tanishq", "Tanaya", "Dinesh", "Mukesh"];
  return (
    <>
      {arr
        .filter((element) => {
          if (!element.startsWith("T")) {
            return element;
          }
        })
        .map((element, index) => {
          return (
            <h1
            //   onMouseOver={() => {
            //     alert(element);
            //   }}
              key={index}
            >
              {element}
            </h1>
          );
        })}
    </>
  );
}

export default FuncComp;
